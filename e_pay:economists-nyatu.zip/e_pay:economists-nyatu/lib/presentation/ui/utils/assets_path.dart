class AssetsPath{
  static const String _images= 'assets/images';
  static const String appLogo= '$_images/logo1.png';
}