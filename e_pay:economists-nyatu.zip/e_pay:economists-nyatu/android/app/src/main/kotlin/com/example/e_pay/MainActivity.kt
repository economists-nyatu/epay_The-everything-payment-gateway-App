package com.example.e_pay

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
